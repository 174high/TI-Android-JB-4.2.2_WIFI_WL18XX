/*
 * This file is released under the terms of GPL v2 and any later version.
 * See the file COPYING in the root directory of the source tree for details.
 *
 * Copyright (C) 2003 Wolfgang Denk, DENX Software Engineering, wd@denx.de
 */

extern ulong uboot_end_data;
extern ulong uboot_end;

extern int incaip_set_cpuclk(void);
