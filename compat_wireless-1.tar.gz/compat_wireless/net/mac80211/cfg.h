/*
 * mac80211 configuration hooks for cfg80211
 */
#ifndef __CFG_H
#define __CFG_H

extern const struct cfg80211_ops mac80211_config_ops;

#endif /* __CFG_H */
