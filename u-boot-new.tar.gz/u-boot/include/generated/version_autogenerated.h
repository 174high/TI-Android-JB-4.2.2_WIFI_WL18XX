#define PLAIN_VERSION "2013.01.01"
#define U_BOOT_VERSION "U-Boot 2013.01.01"
#define CC_VERSION_STRING "arm-eabi-gcc (GCC) 4.6.x-google 20120106 (prerelease)"
#define LD_VERSION_STRING "GNU ld (GNU Binutils) 2.21"
