#define U_BOOT_DATE "May 13 2015"
#define U_BOOT_TIME "17:44:18"
